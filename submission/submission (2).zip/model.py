# -*- coding: utf-8 -*-
"""
model.py (Codabench)
Fast inference:
- MobileNetV3-Small
- Saab folded into saab_linear
- mean+max pooling (event-level)
- multi-head (3 targets)
- Calibration: LNT A,b; sigma_scale; var_temp
- Extra long-horizon sigma floor to reduce overconfidence (helps OOD 1y/2y CRPS)
"""

import os
import io
import math
import pickle
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from torchvision import transforms
from torchvision.models import mobilenet_v3_small

try:
    n_threads = int(os.environ.get("TORCH_NUM_THREADS", "2"))
    n_threads = max(1, min(n_threads, 8))
    torch.set_num_threads(n_threads)
    torch.set_num_interop_threads(1)
except Exception:
    pass

WEIGHT_FILENAME = "model_weights.pth"
ENCODERS_FILENAME = "encoders.pkl"
LNT_FILENAME = "lnt_calibration.npz"
EPS = 1e-6

def _torch_load_weights_only_compat(path: str):
    try:
        return torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        return torch.load(path, map_location="cpu")

def _open_image(maybe_img: Any, search_roots: List[str], image_side: int) -> Image.Image:
    def black():
        return Image.new("RGB", (image_side, image_side), (0, 0, 0))

    if maybe_img is None:
        return black()

    try:
        if isinstance(maybe_img, Image.Image):
            return maybe_img.convert("RGB")
        if isinstance(maybe_img, (bytes, bytearray)):
            return Image.open(io.BytesIO(maybe_img)).convert("RGB")
        if isinstance(maybe_img, dict):
            if maybe_img.get("bytes") is not None:
                return Image.open(io.BytesIO(maybe_img["bytes"])).convert("RGB")
            p = maybe_img.get("path")
            if isinstance(p, str):
                if os.path.exists(p):
                    return Image.open(p).convert("RGB")
                for r in search_roots:
                    cand = os.path.join(r, p)
                    if os.path.exists(cand):
                        return Image.open(cand).convert("RGB")
            return black()
        if isinstance(maybe_img, str):
            p = maybe_img
            if os.path.exists(p):
                return Image.open(p).convert("RGB")
            for r in search_roots:
                cand = os.path.join(r, p)
                if os.path.exists(cand):
                    return Image.open(cand).convert("RGB")
            return black()
    except Exception:
        return black()

    return black()

class MobileNetV3SmallBackbone(nn.Module):
    def __init__(self):
        super().__init__()
        try:
            m = mobilenet_v3_small(weights=None)
        except Exception:
            m = mobilenet_v3_small(pretrained=False)
        self.features = m.features
        self.pool = nn.AdaptiveAvgPool2d(1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.pool(x).flatten(1)
        return x

class FastEventModelMultiHead(nn.Module):
    def __init__(self, k_dim: int, proj_dim: int,
                 species_vocab: int, domain_vocab: int, site_vocab: int,
                 meta_embed_dim: int, meta_dropout: float,
                 pri_dim: int, max_images_per_event: int):
        super().__init__()
        self.max_images_per_event = int(max_images_per_event)

        self.backbone = MobileNetV3SmallBackbone()
        self.saab_linear = nn.Linear(576, int(k_dim), bias=True)

        self.project = nn.Sequential(
            nn.Linear(int(k_dim), int(proj_dim)),
            nn.GELU(),
            nn.Dropout(0.05),
        )

        self.species_emb = nn.Embedding(max(1, int(species_vocab)), int(meta_embed_dim))
        self.domain_emb  = nn.Embedding(max(1, int(domain_vocab)),  int(meta_embed_dim))
        self.site_emb    = nn.Embedding(max(1, int(site_vocab)),    int(meta_embed_dim))
        self.meta_drop = nn.Dropout(float(meta_dropout))

        fused_dim = (2 * int(proj_dim)) + (3 * int(meta_embed_dim)) + 2 + int(pri_dim)

        self.shared = nn.Sequential(
            nn.LayerNorm(fused_dim),
            nn.Linear(fused_dim, 384),
            nn.GELU(),
            nn.Dropout(0.25),
            nn.Linear(384, 192),
            nn.GELU(),
            nn.Dropout(0.15),
        )

        def head_block():
            return nn.Sequential(
                nn.Linear(192, 128),
                nn.GELU(),
                nn.Dropout(0.10),
                nn.Linear(128, 2),
            )
        self.head_0 = head_block()
        self.head_1 = head_block()
        self.head_2 = head_block()

    def forward(self, images_list: List[torch.Tensor],
                sp_idx: torch.Tensor, dm_idx: torch.Tensor, st_idx: torch.Tensor,
                pri: torch.Tensor):
        dev = next(self.parameters()).device
        lengths = [int(x.shape[0]) for x in images_list]
        x = torch.cat([t.to(dev) for t in images_list], dim=0)

        feats = self.backbone(x).float()
        z = self.saab_linear(feats).float()
        z = self.project(z)

        splits = torch.split(z, lengths, dim=0)
        pooled_list = []
        for f in splits:
            mean = f.mean(dim=0)
            mx = f.max(dim=0).values
            pooled_list.append(torch.cat([mean, mx], dim=0))
        pooled = torch.stack(pooled_list, dim=0)

        sp = self.meta_drop(self.species_emb(sp_idx.to(dev)))
        dm = self.meta_drop(self.domain_emb(dm_idx.to(dev)))
        st = self.meta_drop(self.site_emb(st_idx.to(dev)))

        n_imgs = torch.tensor(lengths, dtype=torch.float32, device=dev).view(-1, 1)
        n_imgs_norm = n_imgs / float(self.max_images_per_event)
        n_imgs_log  = torch.log1p(n_imgs)

        pri = pri.to(dev, dtype=torch.float32)
        fused = torch.cat([pooled, sp, dm, st, n_imgs_norm, n_imgs_log, pri], dim=1)

        h = self.shared(fused)

        o0 = self.head_0(h)
        o1 = self.head_1(h)
        o2 = self.head_2(h)

        mu = torch.stack([o0[:, 0], o1[:, 0], o2[:, 0]], dim=1)
        log_sigma = torch.stack([o0[:, 1], o1[:, 1], o2[:, 1]], dim=1)
        log_sigma = torch.clamp(log_sigma, -7.0, 3.0)
        return mu, log_sigma

class Model:
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model: Optional[nn.Module] = None
        self.loaded = False

        self.species_map: Dict[str, int] = {}
        self.domain_map: Dict[str, int] = {}
        self.site_map: Dict[str, int] = {}
        self.priors: Dict[str, Any] = {}

        self.target_mean = np.array([0.0, 0.0, 0.0], np.float32)
        self.target_std  = np.array([1.0, 1.0, 1.0], np.float32)

        self.image_side = 160
        self.max_images_per_event = 4
        self.sigma_floor_long_std_frac = 0.06

        self.lnt_A = None
        self.lnt_b = None
        self.lnt_sigma_scale = None
        self.lnt_var_temp = None

        self._transform = None

    def _candidate_dirs(self) -> List[str]:
        file_dir = os.path.dirname(os.path.abspath(__file__))
        cwd = os.getcwd()
        cands = [file_dir]
        if cwd not in cands:
            cands.append(cwd)
        for d in ["/app/ingested_program", "/app/program", "/app"]:
            if d not in cands:
                cands.append(d)
        out = []
        for d in cands:
            out.append(d)
            out.append(os.path.join(d, "artifacts"))
        uniq = []
        for d in out:
            if d not in uniq:
                uniq.append(d)
        return uniq

    def _find_file(self, dirs: List[str], filename: str) -> Optional[str]:
        for d in dirs:
            p = os.path.join(d, filename)
            if os.path.exists(p):
                return p
        return None

    def load(self):
        cands = self._candidate_dirs()
        enc_path = self._find_file(cands, ENCODERS_FILENAME)
        w_path   = self._find_file(cands, WEIGHT_FILENAME)
        lnt_path = self._find_file(cands, LNT_FILENAME)

        if enc_path is None or w_path is None:
            raise RuntimeError(f"Missing artifacts. enc={enc_path}, weights={w_path}. Searched={cands}")

        with open(enc_path, "rb") as f:
            enc = pickle.load(f)

        self.species_map = enc.get("species_map", {}) or {}
        self.domain_map  = enc.get("domain_map", {}) or {}
        self.site_map    = enc.get("site_map", {}) or {}
        self.priors      = enc.get("priors", {}) or {}

        cfg = enc.get("config", {}) if isinstance(enc.get("config", {}), dict) else {}
        self.image_side = int(cfg.get("image_side", self.image_side))
        self.max_images_per_event = int(cfg.get("max_images_per_event", self.max_images_per_event))
        self.sigma_floor_long_std_frac = float(cfg.get("sigma_floor_long_std_frac", self.sigma_floor_long_std_frac))
        pri_dim = int(cfg.get("pri_dim", 12))
        proj_dim = int(cfg.get("proj_dim", 224))
        meta_embed_dim = int(cfg.get("meta_embed_dim", 96))
        meta_dropout = float(cfg.get("meta_dropout", 0.1))
        k_dim = int(cfg.get("saab_k_dim", 192))

        self.target_mean = np.asarray(enc.get("target_mean", self.target_mean), dtype=np.float32)
        self.target_std  = np.asarray(enc.get("target_std",  self.target_std),  dtype=np.float32)

        self._transform = transforms.Compose([
            transforms.Resize((self.image_side, self.image_side)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225]),
        ])

        sd = _torch_load_weights_only_compat(w_path)

        if "saab_linear.weight" in sd:
            k_dim = int(sd["saab_linear.weight"].shape[0])
        if "project.0.weight" in sd:
            proj_dim = int(sd["project.0.weight"].shape[0])
        if "species_emb.weight" in sd:
            species_vocab = int(sd["species_emb.weight"].shape[0])
            meta_embed_dim = int(sd["species_emb.weight"].shape[1])
        else:
            species_vocab = max(1, len(self.species_map) + 1)
        domain_vocab = int(sd["domain_emb.weight"].shape[0]) if "domain_emb.weight" in sd else max(1, len(self.domain_map) + 1)
        site_vocab   = int(sd["site_emb.weight"].shape[0]) if "site_emb.weight" in sd else max(1, len(self.site_map) + 1)

        self.model = FastEventModelMultiHead(
            k_dim=k_dim,
            proj_dim=proj_dim,
            species_vocab=species_vocab,
            domain_vocab=domain_vocab,
            site_vocab=site_vocab,
            meta_embed_dim=meta_embed_dim,
            meta_dropout=meta_dropout,
            pri_dim=pri_dim,
            max_images_per_event=self.max_images_per_event,
        )

        self.model.load_state_dict(sd, strict=True)
        self.model.to(self.device).eval()

        if lnt_path is not None and os.path.exists(lnt_path):
            z = np.load(lnt_path, allow_pickle=False)
            self.lnt_A = z.get("A", None)
            self.lnt_b = z.get("b", None)
            self.lnt_sigma_scale = z.get("sigma_scale", None)
            self.lnt_var_temp = z.get("var_temp", None)

        self.loaded = True

    def _build_priors_vec(self, scientificName: Any, domainID: Any, siteID: Any) -> torch.Tensor:
        pri = torch.zeros((12,), dtype=torch.float32)
        p = self.priors or {}

        sp_mean = p.get("sp_mean", {}) or {}
        dm_mean = p.get("dm_mean", {}) or {}
        st_mean = p.get("st_mean", {}) or {}
        sp_cnt  = p.get("sp_cnt", {})  or {}
        dm_cnt  = p.get("dm_cnt", {})  or {}
        st_cnt  = p.get("st_cnt", {})  or {}

        sk = str(scientificName)
        dk = str(domainID)
        tk = str(siteID)

        vsp = sp_mean.get(sk, None)
        vdm = dm_mean.get(dk, None)
        vst = st_mean.get(tk, None)

        if vsp is not None: pri[0:3] = torch.from_numpy(np.asarray(vsp, np.float32))
        if vdm is not None: pri[3:6] = torch.from_numpy(np.asarray(vdm, np.float32))
        if vst is not None: pri[6:9] = torch.from_numpy(np.asarray(vst, np.float32))

        pri[9]  = math.log1p(float(sp_cnt.get(sk, 0))) / 6.0
        pri[10] = math.log1p(float(dm_cnt.get(dk, 0))) / 6.0
        pri[11] = math.log1p(float(st_cnt.get(tk, 0))) / 6.0
        return pri

    def _event_to_inputs(self, event: Any):
        file_dir = os.path.dirname(os.path.abspath(__file__))
        roots = [os.getcwd(), file_dir, "/app/input", "/app", "/app/data", "/app/input_data"]

        if isinstance(event, list):
            records = event
        elif isinstance(event, dict):
            records = [event]
        else:
            records = [{}]

        images = []
        keys = ["relative_img", "relative_img_loc", "images", "image_paths", "file_path", "filepath", "path", "image"]
        if isinstance(event, list):
            for d in records:
                val = None
                if isinstance(d, dict):
                    for k in keys:
                        if d.get(k) is not None:
                            val = d.get(k)
                            break
                im = _open_image(val, roots, self.image_side)
                images.append(self._transform(im))
                if len(images) >= self.max_images_per_event:
                    break
        else:
            d0 = records[0] if records else {}
            collected = []
            if isinstance(d0, dict):
                for k in keys:
                    v = d0.get(k)
                    if v is None:
                        continue
                    if isinstance(v, list):
                        collected.extend(v)
                    else:
                        collected.append(v)
            for v in collected:
                im = _open_image(v, roots, self.image_side)
                images.append(self._transform(im))
                if len(images) >= self.max_images_per_event:
                    break

        if len(images) == 0:
            images = [self._transform(Image.new("RGB", (self.image_side, self.image_side), (0, 0, 0)))]

        images_tensor = torch.stack(images, dim=0)

        d0 = records[0] if records else {}
        sci = d0.get("scientificName", None) if isinstance(d0, dict) else None
        dom = d0.get("domainID", None) if isinstance(d0, dict) else None
        site = d0.get("siteID", None) if isinstance(d0, dict) else None

        sp_i = self.species_map.get(str(sci), 0)
        dm_i = self.domain_map.get(str(dom), 0)
        st_i = self.site_map.get(str(site), 0)

        pri = self._build_priors_vec(sci, dom, site).view(1, -1)

        sp_idx = torch.tensor([sp_i], dtype=torch.long, device=self.device)
        dm_idx = torch.tensor([dm_i], dtype=torch.long, device=self.device)
        st_idx = torch.tensor([st_i], dtype=torch.long, device=self.device)

        return [images_tensor.to(self.device)], sp_idx, dm_idx, st_idx, pri.to(self.device)

    def predict(self, event: Any) -> Dict:
        if not self.loaded:
            self.load()
        assert self.model is not None

        images_list, sp_idx, dm_idx, st_idx, pri = self._event_to_inputs(event)

        mean = torch.tensor(self.target_mean, dtype=torch.float32, device=self.device).view(1, 3)
        std  = torch.tensor(self.target_std,  dtype=torch.float32, device=self.device).view(1, 3)

        with torch.inference_mode():
            mu_s, log_sigma_s = self.model(images_list, sp_idx, dm_idx, st_idx, pri)
            mu_s = mu_s.float()
            log_sigma_s = log_sigma_s.float()

            if self.lnt_A is not None and self.lnt_b is not None:
                A = torch.tensor(self.lnt_A, dtype=torch.float32, device=self.device)
                b = torch.tensor(self.lnt_b, dtype=torch.float32, device=self.device).view(1, 3)
                mu_s = mu_s @ A + b

            sigma_s = torch.exp(torch.clamp(log_sigma_s, -7.0, 3.0)).clamp_min(EPS)

            if self.lnt_sigma_scale is not None:
                s = torch.tensor(self.lnt_sigma_scale, dtype=torch.float32, device=self.device).view(1, 3)
                sigma_s = (sigma_s * s).clamp_min(EPS)

            if self.lnt_var_temp is not None:
                t = torch.tensor(self.lnt_var_temp, dtype=torch.float32, device=self.device).view(1, 3)
                sigma_s = (sigma_s * t).clamp_min(EPS)

            # long-horizon sigma floor
            floor = torch.tensor([0.0,
                                  self.sigma_floor_long_std_frac,
                                  self.sigma_floor_long_std_frac],
                                 dtype=torch.float32, device=self.device).view(1, 3)
            sigma_s = torch.maximum(sigma_s, floor)

            mu = (mu_s * std + mean).squeeze(0).detach().cpu().numpy().astype(np.float64).tolist()
            sigma = (sigma_s * std).squeeze(0).detach().cpu().numpy().astype(np.float64).tolist()

        return {
            "SPEI_30d": {"mu": float(mu[0]), "sigma": float(sigma[0])},
            "SPEI_1y":  {"mu": float(mu[1]), "sigma": float(sigma[1])},
            "SPEI_2y":  {"mu": float(mu[2]), "sigma": float(sigma[2])},
        }
